<?php
require __DIR__ . '/vendor/autoload.php';
use Google\Cloud\Datastore\DatastoreClient;
use Google\Cloud\Datastore\Entity;
use Google\Cloud\Datastore\EntityIterator;
use Google\Cloud\Datastore\Key;
use Google\Cloud\Datastore\Query\Query;

session_start();
$_SESSION['username'] = null;
$_SESSION['avatar'] = null;
$message = '';
$datastore = new DatastoreClient(['projectId' => 'cc-a2-benmichael']);
if(isset($_POST['submitbutton'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $key = $datastore->key(user, $username);
    $entity = $datastore->lookup($key);
    if(!is_null($entity)) {
        if ($entity['password'] == $password) {
            $_SESSION['username'] = $username;
            $_SESSION['avatar'] = $entity['avatar'];
            header('Location: /main');
            die();
        }
    }
    $message = "Username or Password was Incorrect. Please try again!";
    }
?>


<html>
    <body>
    <head>
    <link href="https://fonts.googleapis.com/css2?family=Balsamiq+Sans&display=swap" rel="stylesheet">    
    <link rel="stylesheet" href="/stylesheets/main.css" type="text/css">
    </head>
<h1>Wellness Calculator</h1>
<h2>Please Log In</h2>
<form method="POST" action="">
    <label for="username">Username: </label>
    <input type="text" name="username" id="username" required="required"><br>
    <label for="password">Password: </label>
    <input type="password" name="password" id="password" required="required"><br>
    <button type="submit" class="button-primary" name="submitbutton" type="submitbutton">Log In</button>
    <?php echo $message; ?>
</form>
<h3>Don't have an account? <a href="/signup">Sign up here!</a></h3>
</body>
</html>