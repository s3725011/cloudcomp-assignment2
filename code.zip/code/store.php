<?php 
    if(isset($_POST['submit'])) {
        $url = 'https://t6yraihyid.execute-api.us-east-1.amazonaws.com/default/storeUserData';
        $options = array(
            'http' => array(
                'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
                'method'  => 'POST',
                'content' => http_build_query($_POST)
            )
        );
        $context  = stream_context_create($options);
        $result = file_get_contents($url, false, $context);
        header('Location: /main');
        die();
    }

?>