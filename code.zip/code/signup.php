<?php
require __DIR__ . '/vendor/autoload.php';
use Google\Cloud\Datastore\DatastoreClient;
use Google\Cloud\Datastore\Entity;
use Google\Cloud\Datastore\EntityIterator;
use Google\Cloud\Datastore\Key;
use Google\Cloud\Datastore\Query\Query;
$message = '';
$datastore = new DatastoreClient(['projectId' => 'cc-a2-benmichael']);
if(isset($_POST['submitbutton'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $kind = 'user';
    $taskKey = $datastore->key($kind, $username);
    $entity = $datastore->lookup($taskKey);
    $task = $datastore->entity($taskKey, [
        'email' => $email,
        'password' => $password,
    ]);
    if(is_null($entity)) {
        $datastore->insert($task);
        header('Location: /');
        die();
    }
    else {
        $message = 'This username is already taken, please choose another one!';
    }
}
?>

<html>
<head>
    <link href="https://fonts.googleapis.com/css2?family=Balsamiq+Sans&display=swap" rel="stylesheet">    
    <link rel="stylesheet" href="/stylesheets/main.css" type="text/css">
</head>
<body>
<h1>Sign Up</h1>
<form method="POST" action="">
    <label for="email">Email: </label>
    <input type="email" name="email" required="required"><br>
    <label for="username">Username: </label>
    <input type="text" name="username" id="username" required="required"><br>
    <label for="password">Password: </label>
    <input type="password" name="password" id="password" required="required"><br>
    <button type="submit" name="submitbutton" type="submitbutton">Sign Up</button><br>
    <?php echo $message; ?>
</form>
</body>
</html>