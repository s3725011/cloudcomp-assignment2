<?php
    require __DIR__ . '/vendor/autoload.php';
    session_start();
    if(isset($_POST['submitbutton'])) {
        $url = 'https://asia-east2-cc-a2-benmichael.cloudfunctions.net/scoreCalculator';
        $toStore = 'https://t6yraihyid.execute-api.us-east-1.amazonaws.com/default/storeUserData';
        $options = array(
            'http' => array(
                'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
                'method'  => 'POST',
                'content' => http_build_query($_POST)
            )
        );
        $context  = stream_context_create($options);
        $result = file_get_contents($url, false, $context);
        $score = $result;
}
?>

<html>
    <head>
    <link href="https://fonts.googleapis.com/css2?family=Balsamiq+Sans&display=swap" rel="stylesheet">    
    <link rel="stylesheet" href="/stylesheets/main.css" type="text/css">
    </head>
    <body>
    <h1>Wellness Test</h1>
    <form method="POST" action=''>
    <label for="weight">Weight (in Kilograms): </label>
    <input type="hidden" name="score" value=<?php echo $result ?>>
    <input type="number" name="weight" id="weight" min="10" max="500"><br>
    <label for="workouttime">Time Spent Working Out (in Minutes): </label>
    <input type="number" name="workouttime" id="workouttime" min="0" max="1440"><br>
    <label for="water">Amount of Water Drunk Daily (in Litres): </label>
    <input type="number" name="water" id="water" min="0" max="20"><br>
    <label for="sleep">Time spent asleep (in Hours): </label>
    <input type="number" name="sleep" id="sleep" min="0" max="24"><br>
    <div id="happiness">
        <label for="happiness">How would you rate your happiness out of 5?</label><br>
        <label for="1">1</label>
        <input type="radio" name="happiness" id="1" value="1">
        <label for="2">2</label>
        <input type="radio" name="happiness" id="2" value="2">
        <label for="3">3</label>
        <input type="radio" name="happiness" id="3" value="3">
        <label for="4">4</label>
        <input type="radio" name="happiness" id="4" value="4">
        <label for="5">5</label>
        <input type="radio" name="happiness" id="5" value="5">
    </div>
    <div id="productivity">
        <label for="productivity">How would you rate your productivity out of 5?</label><br>
        <label for="1">1</label>
        <input type="radio" name="productivity" id="1" value="1">
        <label for="2">2</label>
        <input type="radio" name="productivity" id="2" value="2">
        <label for="3">3</label>
        <input type="radio" name="productivity" id="3" value="3">
        <label for="4">4</label>
        <input type="radio" name="productivity" id="4" value="4">
        <label for="5">5</label>
        <input type="radio" name="productivity" id="5" value="5">  
    </div>
    <div id="social">
        <label for="social">How would you rate your socialising out of 5?</label><br>
        <label for="1">1</label>
        <input type="radio" name="social" id="1" value="1">
        <label for="2">2</label>
        <input type="radio" name="social" id="2" value="2">
        <label for="3">3</label>
        <input type="radio" name="social" id="3" value="3">
        <label for="4">4</label>
        <input type="radio" name="social" id="4" value="4">
        <label for="5">5</label>
        <input type="radio" name="social" id="5" value="5">
    </div>
    <button type="submit" name="submitbutton">Get Score!</button>
    </form>
    <button onclick="window.location.href='/main'">Go Back</button>

    <h2>Your score is: <?php echo $result ?></h2>

    <form action="/store" method="POST">
        <input type="hidden" name="name" value=<?php echo $_SESSION['username'];?>>
        <input type="hidden" name="score" value=<?php echo $score;?>>
        <button type="submit" name="submit">Store Result</button>
    </form>
    </body>
</html>