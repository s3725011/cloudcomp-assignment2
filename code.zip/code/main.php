<?php
require __DIR__ . '/vendor/autoload.php';
use google\appengine\api\cloud_storage\CloudStorageTools;

session_start();
echo "Hello ";
echo $_SESSION['username'];
if ($_SESSION['avatar'] != null) {
    $image_file = "gs://profilepictureswellness/".$_SESSION['avatar'];
    $avi = CloudStorageTools::getImageServingUrl($image_file); }
?>

<html>
    <head>
    <link href="https://fonts.googleapis.com/css2?family=Balsamiq+Sans&display=swap" rel="stylesheet">    
    <link rel="stylesheet" href="/stylesheets/main.css" type="text/css">
    </head>
    <body>
        <br>
        <img src= <?php echo $avi; ?> ><br>
        <button onclick="window.location.href='/test'">Take the Test</button>
        <button onclick="window.location.href='/results'">Past Results</button>
        <button onclick="window.location.href='/settings'">Settings</button>
    </body>
</html>