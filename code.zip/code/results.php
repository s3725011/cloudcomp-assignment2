<?php
    session_start();
    $message = '';
    if($_GET != null) {
        $message = $_GET;
    }
?>

<html>
    <head>
    <link href="https://fonts.googleapis.com/css2?family=Balsamiq+Sans&display=swap" rel="stylesheet">    
    <link rel="stylesheet" href="/stylesheets/main.css" type="text/css">
    </head>
    <body>
    <h1>Past Results</h1>
    <button onclick="window.location.href=('/main')">Go Back</button>
    <form action="https://o2gzfrqv63.execute-api.us-east-1.amazonaws.com/default/getUserData" method="GET">
        <?php echo $message?>
    </form>
  <table>
  <tr>
    <th>Score</th>
    <th>Date</th>
  </tr>
  <tr>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td></td>
    <td></td>
  </tr>
  <tr>
    <td></td>
    <td></td>
  </tr>
</table>
</body>
</html>

