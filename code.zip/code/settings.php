<?php
require __DIR__ . '/vendor/autoload.php';
use Google\Cloud\Storage\StorageClient;
use google\appengine\api\cloud_storage\CloudStorageTools;
use Google\Cloud\Datastore\DatastoreClient;
use Google\Cloud\Datastore\Entity;
use Google\Cloud\Datastore\EntityIterator;
use Google\Cloud\Datastore\Key;
use Google\Cloud\Datastore\Query\Query;

session_start();
$storage = new StorageClient();
$datastore = new DatastoreClient(['projectId' => 'cc-a2-benmichael']);
$options = ['gs_bucket_name' => $bucketname];
if ($_SESSION['avatar'] != null) {
    $image_file = "gs://profilepictureswellness/".$_SESSION['avatar'];
    $image_url = CloudStorageTools::getImageServingUrl($image_file);
}
$bucketname = 'profilepictureswellness';
$bucket = $storage->bucket($bucketname);
$contents = file_get_contents($_SESSION['avatar']);
if(isset($_POST["submit"])) {
    $username = $_SESSION["username"];
    $nameArr = explode('.', $_FILES['file']['name']);
    $filename = $_SESSION['username'].'.'.$nameArr[1];
    $key = $datastore->key(user, $username);
    $task = $datastore->lookup($key);
    $task['avatar'] = $filename;
    $datastore->upsert($task);
    $_SESSION['avatar'] = $filename;
    $data = file_get_contents($_FILES['file']['tmp_name']);
    $object = $bucket->upload($data, [
        'name' => $filename
    ]);
}
?>

<html>
<head>
    <link href="https://fonts.googleapis.com/css2?family=Balsamiq+Sans&display=swap" rel="stylesheet">    
    <link rel="stylesheet" href="/stylesheets/main.css" type="text/css">
</head>
    <body>
        <h1>Change Profile Picture:</h1><br>
        <img src=<?php echo $image_url; ?>><br>
        <form action="" method="POST" enctype="multipart/form-data">
            Select image to upload:
            <input type="file" name="file" id="file"><br>
            <div id="underfile">
            <button type="submit" name="submit">Submit</button>
            </div>
        </form>
        <button onclick="window.location.href='/main'">Go Back</button>
    </body>
</html>